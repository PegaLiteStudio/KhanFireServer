// const LudoGame = require("../managers/ludoGameManager")
// let ss = new LudoGame("asd");
// let player = "6033017709";
// let player2 =  "7085323475";
// ss.addPlayer(player)
// ss.addPlayer(player2)
// // console.log(ss)
// // console.log(ss.getPlayerIndex(player))
// ss.onDiceRoll(player)

let a = {}